require 'test_helper'

class RacerInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
